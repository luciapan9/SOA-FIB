

/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>
#include <list.h>
#include <hardware.h>

char initial_stack[KERNEL_STACK_SIZE]; // Space for the initial system stack
struct list_head readyqueue;

void cpu_idle(void)
{
	__sti();
	while(1)
	{
	;
	}
}

void init_idle (void)
{

}

void init_task1(void) {
	// 1)
	// a. pedimos marco físico para el directorio
	int Dir = alloc_frame ();
	//    obtenemos su @lógica
	page_table_entry *DirAddress = (page_table_entry *) (Dir << 12);
	// b. las entradas del directorio que no necesitemos  las limnpiamos
    clear_page_table(DirAddress);
	// c. pedimos marco físico para TP del kernel
	int TP_kernel = alloc_frame();
	page_table_entry *Dir_TPKernel = (page_table_entry *) (TP_kernel << 12);
	// d. traducciones para la TP del kernel
	set_kernel_pages(Dir_TPKernel);
	// e. pedimos marco físico para la TP del user
	int TP_user = alloc_frame();
	page_table_entry *Dir_TPUser = (page_table_entry *) (TP_user << 12);
	// f. traducciones para la TP del user 
	set_user_pages(Dir_TPUser);
	// g. mapeamos el directorio y las dos TP's para que @lógicas == @físicas
	set_ss_pag(DirAddress,Dir,Dir,0); // directorio
	set_ss_pag(Dir_TPKernel,TP_kernel,TP_kernel,0); // TP kernel
	set_ss_pag(Dir_TPUser,TP_user,TP_user,1); // TP user

	// 2) & 3)
	int PCB_frame= alloc_frame();
	struct task_struct* PCB = (struct task_struct*)(PCB_frame << 12);
	set_ss_pag(Dir_TPKernel,PCB_frame,PCB_frame,0);
	// 4)
	PCB->PID = 1;
	



}


void init_sched()
{
	INIT_LIST_HEAD(&readyqueue);
}

// devuelve el task struct del proceso que esta en RUN
struct task_struct * current2() {
	unsigned int esp;

	__asm__ __volatile__("movl %%esp,%0" : "= g"(esp));

	return (struct task_struct*)(esp & 0xFFFFF000);

}

// dado el list_head l, nos devuelve el task_struct correspondiente
struct task_struct * list_head_to_task_struct(struct list_head* l) {
	return list_entry(l,struct task_struct,list);
}



/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t)
{
       return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t)
{
       return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}

